//한줄 주석
/* 여러줄 주석 */
/* 여러 줄 주석과 같으에 의해 소스코드에 대한 도움말을 생성하는 기능을 함
 * 	@author : 제작자표시
 * @version : 제작자 표시
 * @param : 파라미터표시
 * @return : 리턴값 표시
/**
	@author Joo Yong Sung
	@version 1.0
	<h2> This Class is not for Run-Time but for making  Document</h2>
*/
public class DocsComment{
	/**
	@param num1 num1 is first number
	@param num2 num2 is second number
	@return return plusing num1 and num2
	*/
	public int getTotal(int num1,int num2)
	{
		return num1 +num2;
	}
}